from torch.ao.nn.intrinsic.quantized import LinearReLU

__all__ = [
    'LinearReLU',
]
